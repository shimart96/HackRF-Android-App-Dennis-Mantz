# HackRF  Android App
 Downloaded from https://github.com/demantz/hackrf_android and compiled with latest version of Android Studio and targeting SdkVersion 30
